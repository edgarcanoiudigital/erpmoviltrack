package erp_gpsmoviltrack;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ErpGpsmoviltrackApplicationTests {

	@Test
	void contextLoads() {
	}

}
